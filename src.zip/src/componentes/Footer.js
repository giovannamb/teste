import React from "react";

function Footer() {
  return (
    <footer>
      <h3>Rodapé</h3>
      <p>Direitos reservados © Bom Pão 2024.</p>
    </footer>
  );
}

export default Footer;