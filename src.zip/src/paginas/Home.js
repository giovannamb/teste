import React from "react";
import pao from "../img/pao.jpg"
import "../Home.css"
//import TitlebarBelowMasonryImageList from "src/componentes/

function Home() {
  return (
    <div>
      <h2>Esta é a página principal</h2>
      <div class="pao">
      <img src={pao} alt="Pão de Queijo" id="pao"/>
      <button>clica em mim</button>
      </div> 
      <div class="pao">
      <img src={pao} alt="Pão de Queijo" id="pao"/>
      <button>clica em mim</button>
      </div>
      <p></p>
    </div>
  );
}

export default Home;