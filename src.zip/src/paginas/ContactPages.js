import React from "react";
import "../ContactPages.css"

function ContactPages() {
  return (
    <div>
      <h2>Contato</h2>
          <p>Aqui você pode encontrar maneiras de entrar em contato conosco.</p>
          <p>Telefone: (11) 91309-2014</p>
          <p>Endereço: Avenida Coronel Manuel da Silva, 2098 - Zona Sul</p>
    </div>
  );
}

export default ContactPages;