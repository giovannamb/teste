import React from "react";

function Produtos() {
  return (
    <div>
      <h2>Bem-vindo à Página de produtos</h2>
      <p>Esta página deverá oferecer o CRUD para produtos ao administrador</p>
    </div>
  );
}

export default Produtos;