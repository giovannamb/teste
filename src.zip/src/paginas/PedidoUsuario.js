import React from "react";

function PedidoUsuario() {
  return (
    <div>
      <h2>Bem-vindo à Página de Pedido do Usuario</h2>
      <p>
        Esta página deverá mostrar a lista de produtos com a quantidade
        escolhida pelo usuário, bem como o valor total a ser pago e dar a ele
        a opção de pagar o pedido, cancelar ou alterar a lista de produtos incluidos
      </p>
    </div>
  );
}

export default PedidoUsuario;