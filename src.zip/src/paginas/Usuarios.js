import React from "react";

function Usuarios() {
  return (
    <div>
      <h2>Bem-vindo à Página de Usuarios</h2>
      <p>Esta página deverá oerecer o CRUD de usuarios para o administrador</p>
    </div>
  );
}

export default Usuarios;