import React from "react";

function PerfilUsuario() {
  return (
    <div>
      <h2>Bem-vindo à Página do Perfil do Usuario</h2>
      <p>
        Esta página deverá conter as opções do usuário alterar
        seu nome, email ou senha após realizar seu login no sistema
      </p>
    </div>
  );
}

export default PerfilUsuario;