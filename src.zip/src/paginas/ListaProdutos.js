import React from "react";

function ListaProdutos() {
  return (
    <div>
      <h2>Bem-vindo à Página de lista de produtos</h2>
      <p>
        Esta página deverá oferecr ao usuário uma lista contendo
        os produtos que podem ser comprados da nossa padaria e 
        mostrar o preço por unidade de cada item.
        </p>
    </div>
  );
}

export default ListaProdutos;