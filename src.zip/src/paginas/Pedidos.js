import React from "react";

function Pedidos() {
  return (
    <div>
      <h2>Bem-vindo à Página de Pedidos</h2>
      <p>Esta página deverá mostrar o CRUD para pedidos ao administrador.</p>
    </div>
  );
}

export default Pedidos;